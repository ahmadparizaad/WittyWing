const t="https://twitter-automation-ek5d.onrender.com/";export{t as S};
