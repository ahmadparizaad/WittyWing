const t="https://twitter-automation-ek5d.onrender.com".replace(/\/+$/,"");export{t as S};
